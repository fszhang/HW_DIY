#ifndef __LCD5110_H_
#define __LCD5110_H_

#include <REG52.H>

#define uint    unsigned int
#define uchar   unsigned char

sbit    LCD5110_LED		=P2^2;
sbit    LCD5110_SCE		=P2^4;      
sbit    LCD5110_RES		=P2^3;      
sbit    LCD5110_DC		=P2^5;        
sbit    LCD5110_SDIN	=P2^6;     
sbit    LCD5110_SCLK	=P2^7;           

void LCD_delayms(unsigned  int ii);
void LCD_write_byte(unsigned char dt, unsigned char command);
void LCD_init(void);
void LCD_set_XY(unsigned char X, unsigned char Y);
void LCD_clear(void); 
void LCD_write_logo(void);
void LCD_disInt(uchar x,uchar y,uint dis_Int);
void LCD_Print(uchar x, uchar y,  uchar ch[]);
void delay( uint sec );

#endif